/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "backend.h"
#include "sqlite3.h"
#include <assert.h>
#include <mqueue.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static char sent[4][420];static int nsent,fail_send;
mqd_t __wrap_mq_open(const char *name,int flags,...){(void)flags;assert(!strcmp(name,"/player"));return 42;}
int __wrap_mq_timedsend(mqd_t q,const char *s,size_t n,unsigned pri,const struct timespec *t){(void)pri;(void)t;assert(q==42 && nsent<4 && n<420);if(fail_send)return -1;memcpy(sent[nsent],s,n);sent[nsent++][n]=0;return 0;}
int __wrap_mq_close(mqd_t q){assert(q==42);return 0;}
static void sql(sqlite3 *d,const char *s){char *e=NULL;if(sqlite3_exec(d,s,0,0,&e)!=SQLITE_OK){fprintf(stderr,"%s\n",e);abort();}}
static void reset(void){for(int i=0;i<album_count;i++)release_artwork(&albums[i]);memset(albums,0,sizeof albums);album_count=0;atomic_store(&prepared,0);atomic_store(&progress,0);}
int main(void){
 unlink("/tmp/roulette-test-song.db");unlink("/tmp/roulette-test-config.db");sqlite3 *d,*c;
 assert(sqlite3_open("/tmp/roulette-test-song.db",&d)==SQLITE_OK);
 sql(d,"CREATE TABLE SONG(ID INTEGER PRIMARY KEY,ALBUM TEXT,ARTIST TEXT,ALBUM_ARTIST TEXT,PATH TEXT,DISC INT,TRACK INT,TITLE TEXT,TITLE_CODE INT,NAME_CODE INT)");
 assert(sqlite3_open("/tmp/roulette-test-config.db",&c)==SQLITE_OK);
 sql(c,"CREATE TABLE SYSCONFIG(ID INT,ARTIST_CLASS_TYPE INT);INSERT INTO SYSCONFIG VALUES(1,1)");sqlite3_close(c);
 prepare_albums(NULL);assert(atomic_load(&prepared)==-1 && album_count==0);reset();
 char err[160];mdb_plan_t plan;
 /* Every boundary, including two artists' short releases sharing one title. */
 for(int tracks=1;tracks<=3;tracks++){
   sql(d,"DELETE FROM SONG");
   for(int i=1;i<=tracks;i++){char s[300];snprintf(s,sizeof s,"INSERT INTO SONG VALUES(%d,'Short','Artist','Artist','/missing/%d.flac',1,%d,'Track',%d,%d)",i,i,i,i,i);sql(d,s);}
   prepare_albums(NULL);assert(atomic_load(&prepared)==-1 && album_count==0);reset();
 }
 sql(d,"DELETE FROM SONG");
 sql(d,"INSERT INTO SONG VALUES(1,'One','Artist','Artist','/missing/1.flac',1,2,'Two',2,2),(2,'One','Artist','Artist','/missing/2.flac',1,1,'One',1,1),(3,'One','Artist','Artist','/missing/3.flac',2,2,'Four',4,4),(4,'One','Artist','Artist','/missing/4.flac',2,1,'Three',3,3)");
 prepare_albums(NULL);assert(atomic_load(&prepared)==1 && album_count==1);
 assert(mdb_album_plan(&albums[0].key,&plan));assert(plan.list_type==3 && plan.count==4 && plan.ids[0]==2 && plan.ids[1]==1 && plan.ids[2]==4 && plan.ids[3]==3);mdb_plan_free(&plan);
 assert(play_album(0,err,sizeof err));assert(nsent==3);assert(!strcmp(sent[0],"0102000C0000"));assert(!strcmp(sent[1],"0100001300000003One"));
 nsent=0;fail_send=1;assert(!play_album(0,err,sizeof err) && nsent==0);fail_send=0;
 sql(d,"DELETE FROM SONG WHERE ID=4");assert(!play_album(0,err,sizeof err) && nsent==0);
 sql(d,"INSERT INTO SONG VALUES(4,'One','Artist','Artist','/missing/4.flac',2,1,'Three',3,3)");reset();
 for(int i=5;i<=8;i++){char s[300];snprintf(s,sizeof s,"INSERT INTO SONG VALUES(%d,'One','Other','Other','/missing/%d.flac',1,%d,'Track',%d,%d)",i,i,i-4,i,i);sql(d,s);}
 prepare_albums(NULL);assert(album_count==2);for(int i=0;i<2;i++){assert(mdb_album_plan(&albums[i].key,&plan));assert(plan.list_type==7 && plan.count==4);mdb_plan_free(&plan);}reset();
 sql(d,"DELETE FROM SONG WHERE ID IN (3,4,7,8)");prepare_albums(NULL);assert(album_count==0);reset();
 sql(d,"DELETE FROM SONG");sql(d,"BEGIN");
 for(int i=0;i<1000;i++)for(int j=0;j<(i%3==0?3:4);j++){char s[500];snprintf(s,sizeof s,"INSERT INTO SONG VALUES(%d,'Album %04d','Artist','Artist','/missing/%d-%d.flac',1,%d,'Track',%d,%d)",i*4+j+1,i,i,j,j+1,j+1,j+1);sql(d,s);}sql(d,"COMMIT");
 prepare_albums(NULL);assert(album_count==POOL && atomic_load(&prepared)==1);int upper=0;
 for(int i=0;i<POOL;i++){int a=atoi(albums[i].key.album+6);assert(a%3!=0);if(a>=600)upper++;for(int j=i+1;j<POOL;j++)assert(strcmp(albums[i].key.album,albums[j].key.album));assert(albums[i].pixels[0]==0);assert((albums[i].pixels[(DISC/2)*DISC+DISC/2]>>24)==255);}
 assert(upper>0);reset();sqlite3_close(d);
 puts("PASS: 1/2/3 tracks excluded; 4 included; 37 unique qualifying albums from 1000; duplicate titles remain separated; disc/track ordering; sequential-before-play; removed-track revalidation; IPC failure; circular alpha masks.");return 0;
}
