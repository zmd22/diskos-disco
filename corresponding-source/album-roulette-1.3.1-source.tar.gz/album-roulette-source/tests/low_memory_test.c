/* Regression: all 37 choices share one placeholder under decoder pressure. */
#include "../src/backend.c"
#include <assert.h>
int memory_headroom(uint64_t required){(void)required;return 0;}
void runtime_log(const char *message){(void)message;}
int main(void){
 for(int pass=0;pass<3;pass++){
  for(int i=0;i<POOL;i++){
   artwork(&albums[i],"/tmp",i);
   assert(albums[i].pixels==fallback_pixels);
   assert(!albums[i].pixels_mapped);
  }
  assert(heap_covers==0);
  for(int i=0;i<POOL;i++)release_artwork(&albums[i]);
 }
 puts("PASS: 37 covers share one fallback through three prepare/release cycles at low RAM.");
 return 0;
}
