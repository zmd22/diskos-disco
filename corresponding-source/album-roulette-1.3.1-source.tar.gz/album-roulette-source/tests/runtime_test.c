/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "runtime.h"
#include <assert.h>
#include <stdio.h>
static void mem(const char *s){FILE *f=fopen("/tmp/roulette-memory-fixture","w");assert(f);fputs(s,f);fclose(f);}
int main(void){
    mem("MemFree: 100 kB\nMemAvailable: 49152 kB\n");assert(memory_headroom(49152));assert(!memory_headroom(49153));
    mem("MemFree: 16384 kB\nCached: 90000 kB\nShmem: 90000 kB\n");assert(memory_headroom(16384));assert(!memory_headroom(16385));
    mem("MemFree: 8192 kB\nCached: 16384 kB\nBuffers: 2048 kB\nSReclaimable: 2048 kB\nShmem: 4096 kB\n");assert(memory_headroom(16384));assert(!memory_headroom(16385));
    mem("broken\n");assert(!memory_headroom(1));remove("/tmp/roulette-memory-fixture");assert(!memory_headroom(1));
    puts("RAM guard thresholds and missing/old-kernel meminfo: passed.");return 0;
}
