/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <stdio.h>
#include <stdint.h>
int main(int argc,char **argv){
 if(argc!=4)return 2;FILE *log=fopen("/tmp/roulette-cache-test/decodes","ab");if(!log)return 7;fputc('x',log);fclose(log);
 FILE *f=fopen(argv[3],"wb");if(!f)return 7;
 for(int y=0;y<360;y++)for(int x=0;x<360;x++){uint32_t c=0xff000000u|((x%256)<<16)|((y%256)<<8)|0x55;fwrite(&c,4,1,f);}return fclose(f)?7:0;
}
