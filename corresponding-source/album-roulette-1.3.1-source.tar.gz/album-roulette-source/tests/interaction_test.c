/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Exercise real LVGL pointer handling, including long-press release suppression. */
#define main roulette_app_main
#include "../src/main.c"
#undef main
#include <assert.h>
#include <sys/mman.h>
static uint32_t test_time=1000;
static lv_indev_data_t pointer;
static uint32_t test_tick(void){return test_time;}
static void pointer_read(lv_indev_t *indev,lv_indev_data_t *out){(void)indev;*out=pointer;}
static void finish_redo(void){test_time+=REDO_MS+1;timer(NULL);assert(stage==LANDING);assert(lv_obj_has_flag(fade,LV_OBJ_FLAG_HIDDEN));}
static void touch(lv_indev_t *indev,int x,int y,lv_indev_state_t state,unsigned elapsed){
    test_time+=elapsed;pointer.point.x=x;pointer.point.y=y;pointer.state=state;lv_indev_read(indev);
}
int main(void){
    preview_mode=1;lv_init();assert(display_open(1));lv_tick_set_cb(test_tick);app_theme_init(NULL);build();
    album_count=POOL;
    for(int i=0;i<POOL;i++){albums[i].pixels=malloc(DISC*DISC*4);assert(albums[i].pixels);placeholder(albums[i].pixels,i);snprintf(albums[i].key.album,MDB_STR,"Album %d",i);}
    /* Render and reshuffle real read-only mappings, not only heap-backed previews. */
    for(int i=0;i<POOL;i++){
        char path[]="/tmp/roulette-render-map-XXXXXX";int fd=mkstemp(path);assert(fd>=0);
        assert(write(fd,albums[i].pixels,DISC*DISC*4)==DISC*DISC*4);
        void *mapped=mmap(NULL,DISC*DISC*4,PROT_READ,MAP_PRIVATE,fd,0);assert(mapped!=MAP_FAILED);close(fd);unlink(path);
        release_artwork(&albums[i]);albums[i].pixels=mapped;albums[i].pixels_mapped=1;
    }
    atomic_store(&prepared,1);start_spin();winner();lv_refr_now(NULL);
    lv_indev_t *indev=lv_indev_create();lv_indev_set_type(indev,LV_INDEV_TYPE_POINTER);lv_indev_set_read_cb(indev,pointer_read);
    /* Winner reveal ends fully opaque, even if a frame is late. */
    test_time+=REVEAL_MS+100;timer(NULL);assert(!revealing);
    assert(lv_obj_get_style_opa(ball,0)==255);
    /* Transparent corners cannot start playback. */
    touch(indev,47,1,LV_INDEV_STATE_PRESSED,10);touch(indev,47,1,LV_INDEV_STATE_RELEASED,100);assert(stage==WINNER);
    /* A short cover tap uses the normal playback action. */
    touch(indev,180,100,LV_INDEV_STATE_PRESSED,10);touch(indev,180,100,LV_INDEV_STATE_RELEASED,100);assert(stage==STARTING);
    /* Repeated playback requests are ignored while one is in flight. */
    play_cb(NULL);assert(stage==STARTING);
    snprintf(play_error,sizeof play_error,"Test failure");atomic_store(&played,-1);timer(NULL);
    assert(stage==WINNER);assert(!strcmp(lv_label_get_text(artist),"Unknown artist"));
    assert(!lv_obj_has_state(ball,LV_STATE_DISABLED));
    /* Modal errors block cover actions; retry uses the same winning album. */
    lv_obj_send_event(discs[1],LV_EVENT_LONG_PRESSED,NULL);assert(stage==WINNER);
    play_cb(NULL);assert(stage==STARTING);assert(lv_obj_has_flag(error_panel,LV_OBJ_FLAG_HIDDEN));
    winner();lv_obj_remove_state(ball,LV_STATE_DISABLED);lv_refr_now(NULL);
    /* Long press returns to landing, and release must not play. */
    touch(indev,180,100,LV_INDEV_STATE_PRESSED,10);touch(indev,180,100,LV_INDEV_STATE_PRESSED,800);assert(stage==REDO);
    touch(indev,180,100,LV_INDEV_STATE_RELEASED,10);assert(stage==REDO);finish_redo();
    /* Another spin restores every sprite, then the ball still plays. */
    go_cb(NULL);assert(stage==SPINNING);
    for(int i=0;i<3;i++)assert(!lv_obj_has_flag(discs[i],LV_OBJ_FLAG_HIDDEN));
    winner();lv_refr_now(NULL);
    for(int repeat=0;repeat<100;repeat++){
        lv_obj_send_event(discs[1],LV_EVENT_LONG_PRESSED,NULL);assert(stage==REDO);finish_redo();
        go_cb(NULL);assert(stage==SPINNING);
        for(int i=0;i<recent_count;i++)assert(!same_album(&albums[winning].key,&recent[i]));
        test_time+=SPIN_MS;timer(NULL);assert(stage==SETTLING);
        play_cb(NULL);assert(stage==SETTLING);
        test_time+=SETTLE_MS+1;timer(NULL);assert(stage==WINNER);
        test_time+=REVEAL_MS+1;timer(NULL);lv_refr_now(NULL);
        assert(lv_obj_get_child_count(spin)==8);assert(lv_image_get_scale_x(discs[1])==256);
        assert(lv_obj_get_style_opa(ball,0)==255);
        assert(lv_image_get_src(discs[1])==&images[winning]);assert(images[winning].data==(const uint8_t*)albums[winning].pixels);
    }
    /* Small pools cannot deadlock on recent-history exclusions. */
    int original_count=album_count;
    for(int small=1;small<=3;small++){
        lv_obj_send_event(discs[1],LV_EVENT_LONG_PRESSED,NULL);finish_redo();album_count=small;
        go_cb(NULL);assert(stage==SPINNING && winning>=0 && winning<small);winner();
        test_time+=REVEAL_MS+1;timer(NULL);lv_refr_now(NULL);
    }
    album_count=original_count;
    touch(indev,180,226,LV_INDEV_STATE_PRESSED,10);
    test_time+=120;lv_anim_refr_now();assert(lv_obj_get_style_transform_width(ball,0)<0);touch(indev,180,226,LV_INDEV_STATE_RELEASED,100);assert(stage==STARTING);
    assert(lv_obj_get_style_border_width(ball,0)==1);
    assert(lv_color_eq(lv_obj_get_style_bg_color(ball,LV_PART_MAIN),lv_color_white()));
    assert(lv_color_eq(lv_obj_get_style_text_color(ball,LV_PART_MAIN),lv_color_black()));
    timer(NULL);assert(stage==ZOOMING);
    int previous_scale=256,previous_opacity=0;
    for(int i=0;i<=20;i++){
        zoom(i/20.0f);int scale=lv_image_get_scale_x(discs[1]);int opacity=lv_obj_get_style_opa(fade,0);
        assert(scale>=previous_scale && opacity>=previous_opacity);previous_scale=scale;previous_opacity=opacity;
    }
    assert(lv_obj_get_y(discs[1])==180-DISC/2);assert(previous_opacity==255);
    test_time+=ZOOM_MS+100;timer(NULL);assert(quit);
    display_save("/tmp/roulette-final-frame.ppm");
    lv_deinit();display_close();free(themed_rim);for(int i=0;i<album_count;i++)release_artwork(&albums[i]);
    puts("Gestures, 100 repeat spins, recent exclusions/small pools, settling/redo transitions, button feedback, playback error/retry, duplicate taps, reveal and zoom endpoints: passed.");return 0;
}
