#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/test
flags='-Os -std=gnu11 -pthread -ffunction-sections -fdata-sections -I src -I vendor'
gcc $flags -DDB_PATH='"/tmp/roulette-test-song.db"' -DMDB_SYSCONFIG_PATH='"/tmp/roulette-test-config.db"' -c vendor/musicdb.c -o build/test/musicdb.o
gcc $flags -DDB_PATH='"/tmp/roulette-test-song.db"' -c src/backend.c -o build/test/backend.o
gcc $flags tests/backend_test.c build/test/musicdb.o build/test/backend.o build/host/src/runtime.o build/host/vendor/sqlite3.o -Wl,--gc-sections,--wrap=mq_open,--wrap=mq_timedsend,--wrap=mq_close -lm -lrt -o build/test/backend-test
build/test/backend-test
# Isolated artwork/cache fixtures; never use the real device locations.
rm -rf /tmp/roulette-cache-test
mkdir -p /tmp/roulette-cache-test
cc -O2 tests/fake_artdec.c -o build/test/fake-artdec
gcc $flags -DDB_PATH='"/tmp/roulette-cache-test/song.db"' -DSD_ROOT='"/tmp/roulette-cache-test"' -DCACHE_DIR='"/tmp/roulette-cache-test/.diskos/album-roulette"' -DART_HELPER="\"$PWD/build/test/fake-artdec\"" -c src/backend.c -o build/test/cache-backend.o
gcc $flags tests/cache_test.c build/test/cache-backend.o build/host/src/runtime.o build/test/musicdb.o build/host/vendor/sqlite3.o -Wl,--gc-sections -lm -lrt -o build/test/cache-test
build/test/cache-test

# Real LVGL pointer gestures; requires the host build.
objects=$(find build/host -name "*.o" ! -path "build/host/src/main.o")
gcc $flags -DLV_CONF_INCLUDE_SIMPLE -ffunction-sections -fdata-sections tests/interaction_test.c $objects -Wl,--gc-sections -lm -lrt -o build/test/interaction-test
build/test/interaction-test

gcc $flags -DMEMINFO_PATH='"/tmp/roulette-memory-fixture"' tests/runtime_test.c src/runtime.c -o build/test/runtime-test
build/test/runtime-test
gcc $flags -DART_HELPER='"/bin/true"' tests/decoder_wait_test.c build/host/src/runtime.o -Wl,--gc-sections,--wrap=waitpid,--wrap=kill -lm -lrt -o build/test/decoder-wait-test
build/test/decoder-wait-test
gcc $flags tests/cache_fs_test.c -Wl,--gc-sections,--wrap=statfs,--wrap=statvfs -lm -lrt -o build/test/cache-fs-test
build/test/cache-fs-test
gcc $flags tests/mapping_test.c -Wl,--gc-sections -lm -lrt -o build/test/mapping-test
build/test/mapping-test
# This headroom was rejected by 1.2.3; decoding must now succeed at 24 MiB.
rm -rf /tmp/roulette-cache-test
mkdir -p /tmp/roulette-cache-test
printf 'MemAvailable: 24576 kB\n' > /tmp/roulette-mid-memory
gcc $flags -DMEMINFO_PATH='"/tmp/roulette-mid-memory"' -c src/runtime.c -o build/test/runtime-mid-memory.o
gcc $flags tests/cache_test.c build/test/cache-backend.o build/test/runtime-mid-memory.o build/host/vendor/sqlite3.o -Wl,--gc-sections -lm -lrt -o build/test/cache-mid-memory-test
build/test/cache-mid-memory-test
rm /tmp/roulette-mid-memory
