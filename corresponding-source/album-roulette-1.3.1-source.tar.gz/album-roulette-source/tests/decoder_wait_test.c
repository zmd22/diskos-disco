/* SPDX-License-Identifier: GPL-3.0-or-later */
#define _GNU_SOURCE
#include <errno.h>
#include <assert.h>
#include <sys/wait.h>
#include "../src/backend.c"
/* Force a child-already-reaped outcome: its old PID must never be signalled. */
pid_t __real_waitpid(pid_t,int *,int);
pid_t __wrap_waitpid(pid_t pid,int *status,int options){(void)options;pid_t r;do{r=__real_waitpid(pid,status,0);}while(r<0 && errno==EINTR);errno=ECHILD;return -1;}
int __wrap_kill(pid_t pid,int sig){(void)pid;(void)sig;assert(!"reaped decoder PID was signalled");return -1;}
int main(void){assert(!decode("ignored","/tmp/roulette-child-fixture"));puts("Already-reaped decoder PID is never signalled: passed.");return 0;}
