/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/backend.c"
#include <assert.h>
static unsigned long fake_type;
int __wrap_statfs(const char *path,struct statfs *fs){(void)path;memset(fs,0,sizeof *fs);fs->f_type=fake_type;return 0;}
int __wrap_statvfs(const char *path,struct statvfs *fs){(void)path;(void)fs;assert(!"RAM cache reached storage-capacity check");return -1;}
int main(void){fake_type=0x01021994;cache_init();assert(!cache_available);fake_type=0x858458f6u;cache_init();assert(!cache_available);puts("Persistent cover cache rejected on tmpfs and ramfs: passed.");return 0;}
