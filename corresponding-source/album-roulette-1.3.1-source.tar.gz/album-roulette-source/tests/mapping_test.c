/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "../src/backend.c"
#include <assert.h>
int main(void){
    char path[]="/tmp/roulette-map-XXXXXX";int fd=mkstemp(path);assert(fd>=0);
    assert(!ftruncate(fd,DISC*DISC*4));uint32_t pixel=0xff112233;assert(pwrite(fd,&pixel,4,0)==4);close(fd);
    album_t a={0};assert(cache_map(path,&a));assert(a.pixels_mapped && a.pixels[0]==pixel);
    assert(!unlink(path));assert(a.pixels[0]==pixel); /* Cache eviction leaves a live mapping valid. */
    release_artwork(&a);assert(!a.pixels && !a.pixels_mapped);release_artwork(&a);
    puts("Read-only cover mapping, eviction and repeated cleanup: passed.");return 0;
}
