/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "backend.h"
#include "sqlite3.h"
#include <assert.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#define ROOT "/tmp/roulette-cache-test"
#define CACHE ROOT "/.diskos/album-roulette"
static void reset(void){for(int i=0;i<album_count;i++)release_artwork(&albums[i]);memset(albums,0,sizeof albums);album_count=0;atomic_store(&prepared,0);}
static void writefile(const char *p,const char *s){FILE *f=fopen(p,"wb");assert(f);fputs(s,f);fclose(f);}
static int decodes(void){FILE *f=fopen(ROOT "/decodes","rb");assert(f);int n=0;while(fgetc(f)!=EOF)n++;fclose(f);return n;}
static int caches(char *one){DIR *d=opendir(CACHE);assert(d);struct dirent *e;int n=0;while((e=readdir(d)))if(strlen(e->d_name)==21 && !strcmp(e->d_name+16,".argb")){n++;if(one)snprintf(one,300,CACHE "/%.21s",e->d_name);}closedir(d);return n;}
int main(void){
 mkdir(ROOT,0755);mkdir(ROOT "/music",0755);writefile(ROOT "/music/track.flac","audio");
 sqlite3 *d;assert(sqlite3_open(ROOT "/song.db",&d)==SQLITE_OK);
 assert(sqlite3_exec(d,"CREATE TABLE SONG(ALBUM TEXT,ARTIST TEXT,ALBUM_ARTIST TEXT,PATH TEXT)",0,0,0)==SQLITE_OK);
 for(int i=0;i<4;i++)assert(sqlite3_exec(d,"INSERT INTO SONG VALUES('Test','Artist','Artist','" ROOT "/music/track.flac')",0,0,0)==SQLITE_OK);
 sqlite3_close(d);prepare_albums(NULL);assert(atomic_load(&prepared)==1 && album_count==1 && decodes()==1 && albums[0].pixels_mapped);
 uint32_t pixel=albums[0].pixels[120*DISC+120];assert((pixel>>24)==255 && (pixel&0xffffff)!=0);reset();
 prepare_albums(NULL);assert(decodes()==1 && albums[0].pixels_mapped && albums[0].pixels[120*DISC+120]==pixel);reset();
 char cached[300];assert(caches(cached)==1);writefile(cached,"bad");
 prepare_albums(NULL);assert(decodes()==2 && albums[0].pixels[120*DISC+120]==pixel);reset();
 writefile(ROOT "/music/cover.jpg","changed-sidecar");prepare_albums(NULL);assert(decodes()==3);reset();
 writefile(ROOT "/music/track.flac","changed-audio-file");prepare_albums(NULL);assert(decodes()==4);reset();
 for(int i=0;i<140;i++){char p[300];snprintf(p,sizeof p,CACHE "/%016x.argb",i);writefile(p,"stale");}
 prepare_albums(NULL);assert(atomic_load(&prepared)==1 && caches(NULL)<=128);reset();
 puts("PASS: real decoder spawn; cache hit skips decoder; corrupt cache redecoded; audio and sidecar changes invalidate; 128-cover size cap.");return 0;
}
