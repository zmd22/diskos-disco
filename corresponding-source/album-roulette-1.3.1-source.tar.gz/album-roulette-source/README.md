# Album Roulette 1.3.0

Standalone Snowsky Disc app for diskOS Disco! 1.1.1 / firmware V2.57.

## Update your installed app

Download the compiled file **Album-Roulette-1.3.0** (not the source archive) into:
`/home/altxego/Desktop/diskOS/apps/Album roulette/`

Exit Album Roulette on the Disc first. Enable Debug Mode if SSH has expired.
Run these two lines on your computer after saving the new app file; the existing launcher entry stays valid:

```sh
ssh root@192.168.178.63 'rm -f /usr/data/apps/album-roulette/app /usr/data/apps/album-roulette/app.new'
ssh root@192.168.178.63 'cat > /usr/data/apps/album-roulette/app && chmod 755 /usr/data/apps/album-roulette/app' < '/home/altxego/Desktop/diskOS/apps/Album roulette/Album-Roulette-1.3.0'
```

Open Music > Shortcuts > All apps > Album Roulette.

## Theme support

Reads `/usr/data/diskos.conf` on each launch without modifying it. Uses Disco’s palette/font engine for the saved preset, light/dark/auto appearance, outdoor mode, font size, and saved custom themes. Buttons follow the preset’s fill, border, radius, typography and pressed/disabled rules. Play! is a fixed white ball with black text in every theme. The inner canvas and text use theme roles so light themes stay readable. Ring uses the saved static accent; album-derived accent mode falls back to the theme accent because this standalone app does not receive Disco’s live album accent. Restart Album Roulette after changing the theme.

## Polish in 1.3.0

Built on the user's confirmed-working 1.2.4. The artwork/cache/RAM-guard/playback backend and runtime adapter are byte-for-byte unchanged from that source baseline.

- Small fixed selection mark during the spin. A 3 px final settling movement takes 220 ms, followed by a 100 ms pause and the existing 220 ms winner-control reveal.
- Long album/artist text waits 1.1 seconds before scrolling back and forth at a target 24 px/second, holding 1.1 seconds at each end. Each winner restarts the reading pause. Hidden labels stop scrolling on redo/playback handoff.
- Buttons compress subtly on press and return with 90 ms easing; the Play ball retains white fill, black text and its thin border.
- Secret cover long-press fades through black back to the landing page over 150 ms. Prepared covers are reused.
- Avoid the last three winning album identities within the session. Exclusion shrinks for small pools so a winner is always available. Choice is uniform among the remaining albums; recent history is not persisted.
- Transitions use consistent easing, pre-existing UI objects and elapsed-time animation, targeting 30 fps without per-frame cover decoding.

Regression tests include 100 repeat spins with real read-only mapped cover buffers, correct winner/cover association, recent exclusions and one/two/three-album pools, input gating during settling and redo, button compression, playback-error retries and zoom endpoints. Address/undefined-behavior checks pass on these paths. Light/dark previews were inspected. Physical-device testing remains to be done for 1.3.0.

## Artwork correction in 1.2.4

The 1.2.3 decoder threshold was too conservative and skipped many covers. This version lowers the starting threshold to 16 MiB and stops an active decoder below 8 MiB. Successfully decoded/cached covers use read-only, file-backed mappings on SD instead of retaining about 10 MiB of heap buffers. Linux can reclaim clean mapped pages; if caching/mapping is unavailable, the app retains its heap-backed fallback. Existing valid caches are reused unchanged.

Older kernels without MemAvailable use a conservative estimate including half of potentially reclaimable file cache/buffers/slab, excluding shared-memory/tmpfs pages, rather than counting only MemFree. This estimate is approximate.

Tests explicitly cover decoding at 24 MiB reported headroom, mapped cache hits, mapped-cover eviction/cleanup, and 100 repeat spins rendering read-only mapped covers. Address/undefined-behavior checks pass on the mapped-cover gesture/animation paths. This remains a local check; the device's mq_ui failure has not been reproduced or proven fixed.

## Stability hardening

The reported mq_ui crash is not reproduced or proven fixed without device logs. Roulette is a separate process; its memory pressure can nevertheless affect Disco. This release fixes decoder cleanup and adds protections:

- Reset inherited SIGCHLD handling and never signal a decoder PID after a failed wait has lost ownership of it.
- Require 16 MiB available RAM before new decoding; stop an active decoder below 8 MiB. Cached covers remain usable; low headroom uses placeholders. Below 12 MiB, stop new heap-backed album preparation gracefully; existing cached maps remain usable.
- Prefer terminating Roulette/its decoder during system-wide OOM, using the app's own oom_score_adj=500. This is a preference, not a guarantee, and does not modify mq_ui.
- Enforce one Roulette instance, disable core dumps, and let fatal LVGL assertions abort this app instead of hanging forever.
- Keep the cover cache off tmpfs/ramfs, so an unmounted SD directory cannot become a large RAM cache. Reduce the sampling connection's SQLite page cache to 512 KiB.
- Record memory skips and normal/signal exits in `/usr/data/apps/album-roulette/roulette.log` (bounded by rotation around 64 KiB).

Run this soon after the failure and share the output:

```sh
ssh root@192.168.178.63 'cat /proc/meminfo; dmesg | tail -n 100; tail -n 80 /usr/data/diskos_boot.log; tail -n 60 /usr/data/apps/album-roulette/roulette.log'
```

An OOM-killer entry naming mq_ui differs from Disco's `CAUGHT FATAL SIGNAL` entry. A reboot or later log rotation can erase the evidence. App code cannot catch SIGKILL or log its own OOM termination.

## Changes

- Thin dark border around the permanently white Play! ball.
- Animation update target increased from 20 to 30 fps; actual frame rate depends on the Disc.
- Smooth spinner interpolation, a short winner-text/ball reveal, antialiased zoom and a softer fade to the final black handoff frame.
- Repeat spins reset transforms and visibility; playback failures restore the artist and controls; the error panel blocks hidden cover actions.

- Tap the winning cover to play, just like the Play! ball.
- Long-press the winning cover to return silently to the landing screen. Another spin reshuffles the prepared pool without decoding covers again.

- Up to 37 albums, matching the 37 pockets of European roulette.
- Only albums with at least four indexed tracks qualify, before random sampling.
- Actual count shown if fewer than 37 qualify; same-name albums by different album artists stay separate.
- Subtle red/black rim with the correct European pocket sequence and a green zero.
- White ball circles inside the numbers while covers prepare, then settles. No preparation text.
- Surprise me remains visible; tapping while loading queues the spin.
- Larger landing/button/spin text, 26 px album title and 22 px scrolling artist, moved up.
- White 72 px Play! ball sits fully inside the 268 px album disc, 6 px above its bottom edge.
- Eight-second slowing spin, with all 37 positions visible and top-aligned circular covers, enlarged by 10%.
- Pre-rendered rim, three reused cover objects, fewer idle updates, single-precision cubic easing.
- Antialiased cover edges and bilinear cover resizing, done before animation.
- Optional persistent cover cache under /tmp/sdcard/.diskos/album-roulette, limited to 128 decoded covers (~35 MiB; up to one 37-cover batch of temporary headroom). Cache is skipped with less than 64 MiB free. Updated audio and sidecars invalidate cached covers.
- Retry/Exit error panel; minimum track count checked again at playback.

## Known integration boundaries

The standalone app cannot change the launcher icon in current Disco. Editable roulette-wheel icon artwork is included in assets/roulette-icon.svg for a future Disco launcher change; **the installed launcher icon remains unchanged**.

The cover zooms and fades to black before Disco redraws the previous screen. Launch from Music to return to Music. The app does not switch receiver/audio-output modes: use local playback. Sequential mode is sent to the player; Disco may retain its previous in-memory preference/icon and reapply it on a later playback action.

Four tracks is a size filter, not proof an album is complete. Albums without album tags, or with album/artist identity keys of 160 UTF-8 bytes or more, are excluded. Latin text uses bundled Inter/Montserrat fonts. Mapped covers depend on the SD card remaining mounted while the app runs. Unusual duplicate-name albums use Disco's exact-playlist fallback only if its order matches the album's disc/track order; otherwise playback reports an error. This can update Disco's reserved internal playlist, not user playlists.

## Build and validation

Based on zmd22/diskos-disco commit d9a3be3a140bfd8d790222fd9bec4f226db2feb7. Static little-endian MIPS32r2, FP64, NaN2008.

Version 1.2.4 was reported working by the user. Version 1.3.0 has been built and its polished screens rendered locally; it has not yet been run on a physical Disc. Tests cover track-count boundaries, sampling 37 eligible albums across a 1,000-album library, same-name artist separation, disc/track order, sequential playback framing, send failures, changed album counts, cache hits, corrupt cache recovery, invalidation and the cache limit. Real LVGL pointer tests cover short-tap playback, long-press/release suppression, circular hit testing, a repeat spin, ball playback, repeated taps, failure/retry restoration, and reveal/zoom endpoints. The final handoff frame is verified black. 100 repeat spins also pass. Address/undefined-behavior sanitizer checks pass on the gesture/animation paths; LeakSanitizer cannot run in this environment, so this is not a leak-free certification. RAM thresholds and an already-reaped child are covered by regression tests. Actual device performance and the reported mq_ui failure are not reproduced here.

```sh
make -j8
# build/mips/album-roulette
make host -j8
build/host/album-roulette --preview previews
tests/run.sh
```

Default compiler: /opt/mipsel-n2008-musl-cross/bin/mipsel-linux-musl-gcc. Toolchain config is in toolchain/mcm-config.mak, using musl-cross-make commit 227df8b99103f9c59f6570babf892978e293082f. The pre-generated rim header is included: Python/Pillow and DejaVu Sans are needed only to regenerate artwork with tools/make_rim.py.

GPL-3.0-or-later; see LICENSE, NOTICE.md and licenses/. Vendored sources included. No commit or push was made.
