/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include "lvgl/lvgl.h"
int display_open(int preview);
void display_save(const char *path);
void display_close(void);
