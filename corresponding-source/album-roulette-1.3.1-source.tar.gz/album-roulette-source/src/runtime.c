/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "runtime.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <time.h>
#ifndef MEMINFO_PATH
#define MEMINFO_PATH "/proc/meminfo"
#endif
void runtime_log(const char *message){
    fprintf(stderr,"Album Roulette: %s\n",message);
    const char *path="/usr/data/apps/album-roulette/roulette.log";
    struct stat st;const char *mode=(!stat(path,&st) && st.st_size>65536)?"w":"a";
    FILE *f=fopen(path,mode);if(!f)return;
    fprintf(f,"%ld %s\n",(long)time(NULL),message);fclose(f);
}
int memory_headroom(uint64_t required_kib){
    FILE *f=fopen(MEMINFO_PATH,"r");if(!f)return 0;
    char line[256];unsigned long long value,available=0,free_kib=0,cached=0,buffers=0,reclaimable=0,shmem=0;int have_available=0,have_free=0;
    while(fgets(line,sizeof line,f)){
        if(sscanf(line,"MemAvailable: %llu kB",&value)==1){available=value;have_available=1;}
        if(sscanf(line,"MemFree: %llu kB",&value)==1){free_kib=value;have_free=1;}
        if(sscanf(line,"Cached: %llu kB",&value)==1)cached=value;
        if(sscanf(line,"Buffers: %llu kB",&value)==1)buffers=value;
        if(sscanf(line,"SReclaimable: %llu kB",&value)==1)reclaimable=value;
        if(sscanf(line,"Shmem: %llu kB",&value)==1)shmem=value;
    }
    fclose(f);
    /* Older kernels: count only half of potentially reclaimable cache, excluding tmpfs. */
    uint64_t cache=cached+buffers+reclaimable;
    uint64_t estimate=free_kib+(cache>shmem?(cache-shmem)/2:0);
    return have_available?available>=required_kib:have_free && estimate>=required_kib;
}
int runtime_begin(void){
    static int lock_fd=-1;
    lock_fd=open("/tmp/album-roulette.lock",O_RDWR|O_CREAT|O_CLOEXEC,0600);
    if(lock_fd<0 || flock(lock_fd,LOCK_EX|LOCK_NB)){
        runtime_log("Cannot acquire single-instance lock; exiting.");if(lock_fd>=0)close(lock_fd);return 0;
    }
    /* Prefer terminating this optional app over mq_ui under system-wide OOM. */
    FILE *f=fopen("/proc/self/oom_score_adj","w");
    if(f){fputs("500\n",f);fclose(f);}else runtime_log("OOM preference unavailable.");
    struct rlimit core={0,0};setrlimit(RLIMIT_CORE,&core);
    /* Own children must remain waitable; SIG_IGN can survive the launcher's exec. */
    return 1;
}
