/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include "theme.h"
void app_theme_init(const char *preview_config);
void app_theme_button(lv_obj_t *button,int round_ball);
