/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdint.h>
void runtime_log(const char *message);
int memory_headroom(uint64_t required_kib);
int runtime_begin(void);
