/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "display.h"
#include "controls.h"
#include <fcntl.h>
#include <linux/fb.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
static uint32_t frame[360*360],draw[360*80];
static int fd=-1,rotation,previewing;
static uint8_t *map;
static struct fb_var_screeninfo var;
static struct fb_fix_screeninfo fix;
static uint32_t tick(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint32_t)(t.tv_sec*1000+t.tv_nsec/1000000);}
static void flush(lv_display_t *d,const lv_area_t *a,uint8_t *pixels){
    if(previewing)ctl_blit((uint8_t*)frame,360*4,360,360,2,(uint32_t*)pixels,a->x1,a->y1,a->x2,a->y2);
    else ctl_blit(map+(size_t)var.yoffset*fix.line_length+(size_t)var.xoffset*4,fix.line_length,360,360,rotation,(uint32_t*)pixels,a->x1,a->y1,a->x2,a->y2);
    lv_display_flush_ready(d);
}
int display_open(int preview){
    previewing=preview;
    if(!preview){
        fd=open("/dev/fb0",O_RDWR|O_CLOEXEC);
        if(fd<0 || ioctl(fd,FBIOGET_VSCREENINFO,&var) || ioctl(fd,FBIOGET_FSCREENINFO,&fix))return 0;
        if(var.xres!=360 || var.yres!=360 || var.bits_per_pixel!=32 || var.red.offset!=16 || var.green.offset!=8 || var.blue.offset!=0)return 0;
        if((size_t)(var.yoffset+360)*fix.line_length>fix.smem_len)return 0;
        map=mmap(NULL,fix.smem_len,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
        if(map==MAP_FAILED){map=NULL;return 0;}
        ctl_state_t state;
        if(!ctl_read_state("/usr/data/fiio/db/sysconfig.db",&state) && state.rot>=0 && state.rot<4)rotation=state.rot;
    }
    lv_tick_set_cb(tick);
    lv_display_t *d=lv_display_create(360,360);
    if(!d)return 0;
    lv_display_set_color_format(d,LV_COLOR_FORMAT_XRGB8888);
    lv_display_set_flush_cb(d,flush);
    lv_display_set_buffers(d,draw,NULL,sizeof draw,LV_DISPLAY_RENDER_MODE_PARTIAL);
    if(!preview){
        lv_indev_t *touch=lv_evdev_create(LV_INDEV_TYPE_POINTER,"/dev/input/event1");
        if(!touch)return 0;
        int swap,x0,y0,x1,y1;ctl_rot_touch_cal(rotation,360,&swap,&x0,&y0,&x1,&y1);
        lv_evdev_set_swap_axes(touch,swap);lv_evdev_set_calibration(touch,x0,y0,x1,y1);
    }
    return 1;
}
void display_save(const char *path){
    FILE *f=fopen(path,"wb");if(!f)return;
    fprintf(f,"P6\n360 360\n255\n");
    for(int y=0;y<360;y++)for(int x=0;x<360;x++){
        uint32_t c=frame[y*360+x];int dx=2*x-359,dy=2*y-359;
        if(dx*dx+dy*dy>360*360)c=0xeeeeee;
        unsigned char rgb[]={(c>>16)&255,(c>>8)&255,c&255};fwrite(rgb,1,3,f);
    }
    fclose(f);
}
void display_close(void){if(map)munmap(map,fix.smem_len);if(fd>=0)close(fd);}
