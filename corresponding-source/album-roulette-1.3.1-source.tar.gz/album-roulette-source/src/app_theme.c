/* SPDX-License-Identifier: GPL-3.0-or-later */
/* Read-only host adapter for Disco's actual palette, font and custom-theme engine. */
#include "app_theme.h"
#include "theme_kit.h"
#include "config.h"
#include "fonts_intl.h"
#include "jsmn.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <limits.h>
static struct {char key[64],value[256];} settings[256];
static int nsettings;
const char *cfg_get_str(const char *key,const char *fallback){for(int i=nsettings-1;i>=0;i--)if(!strcmp(settings[i].key,key))return settings[i].value;return fallback;}
int cfg_get_int(const char *key,int fallback){const char *s=cfg_get_str(key,NULL);if(!s || !*s)return fallback;char *end;errno=0;long v=strtol(s,&end,10);if(errno || *end || v<INT_MIN || v>INT_MAX)return fallback;return (int)v;}
/* The shared initializer has defensive setters. No app call writes diskos.conf. */
int cfg_set_int(const char *key,int value){(void)key;(void)value;return 0;}
void cfg_begin(void){}
int cfg_commit(void){return 0;}
int i18n_needs_fallback_font(void){return 1;}
const lv_font_t *ui_font_cjk(int px){
    static lv_font_t chain[4][3];static int built;
    if(!built){
        const lv_font_t *base[]={&lv_font_montserrat_14,&lv_font_montserrat_16,&lv_font_montserrat_18,&lv_font_montserrat_20};
        const lv_font_t *intl[]={&font_intl_14,&font_intl_16,&font_intl_18,&font_intl_20};
        for(int i=0;i<4;i++){chain[i][0]=*base[i];chain[i][1]=*intl[i];chain[i][2]=font_cjk_extra_16;chain[i][0].fallback=&chain[i][1];chain[i][1].fallback=&chain[i][2];}built=1;
    }
    int i=px<=14?0:px<=16?1:px<=18?2:3;return &chain[i][0];
}
/* Only component styles are relevant in an external app. Screen builders belong to mq_ui. */
#define KIT(name,ident) const theme_kit_t name={.id=ident}
KIT(theme_kit_default,"default");KIT(theme_kit_ring,"ring");KIT(theme_kit_braun,"braun");KIT(theme_kit_something,"something");KIT(theme_kit_hifi,"hi-fi");KIT(theme_kit_term,"terminal");KIT(theme_kit_bauh,"bauhaus");KIT(theme_kit_blue,"blueprint");KIT(theme_kit_stone,"stone");KIT(theme_kit_zine,"zine");
const theme_kit_t *theme_kit(void){return theme_kit_for_active();}
void app_theme_init(const char *preview_config){
    FILE *f=fopen(preview_config?preview_config:"/usr/data/diskos.conf","r");char line[512];
    nsettings=0;
    if(f){while(fgets(line,sizeof line,f) && nsettings<256){
        char *nl=strpbrk(line,"\r\n");if(nl)*nl=0;char *eq=strchr(line,'=');
        if(!eq || line[0]=='#' || line[0]==';')continue;*eq++=0;
        if(strlen(line)>=sizeof settings[0].key || strlen(eq)>=sizeof settings[0].value)continue;
        strcpy(settings[nsettings].key,line);strcpy(settings[nsettings++].value,eq);
    }fclose(f);}
    /* Match legacy fork migration in memory only. */
    if(nsettings<255 && cfg_get_int("theme_preset",-1)<0 && cfg_get_int("ui_theme",-1)>=0){
        int old=cfg_get_int("ui_theme",-1);
        snprintf(settings[nsettings].key,64,"theme_preset");snprintf(settings[nsettings++].value,256,"%d",old==0?8:9);
        if(nsettings<256){snprintf(settings[nsettings].key,64,"theme_variant");snprintf(settings[nsettings++].value,256,"%d",old==0 || old==2?0:1);}
    }
    theme_init();
}
static void neutral_button(lv_obj_t *b){
    lv_obj_set_style_bg_color(b,TC(SURFACE_RAISED),0);lv_obj_set_style_text_color(b,TC(TEXT_PRIMARY),0);
    lv_obj_set_style_bg_color(b,TC(RAISED_PRESSED),LV_STATE_PRESSED);
    lv_obj_set_style_bg_color(b,TC(SURFACE),LV_STATE_DISABLED);
    lv_obj_set_style_border_width(b,1,0);lv_obj_set_style_border_color(b,TC(BORDER_STRONG),0);
}
/* Component rules ported from ui/theme_kits.c; palette roles come from theme.c. */
void app_theme_button(lv_obj_t *b,int round_ball){
    const theme_def_t *def=theme_def();const char *name=def?def->name:"Default";
    lv_obj_t *l=lv_obj_get_child(b,0);lv_obj_set_style_shadow_width(b,0,0);
    lv_obj_set_style_bg_color(b,TC(ACTION_SURFACE),0);lv_obj_set_style_bg_color(b,TC(PRIMARY_PRESSED),LV_STATE_PRESSED);
    lv_obj_set_style_bg_color(b,TC(SURFACE),LV_STATE_DISABLED);lv_obj_set_style_text_color(b,TC(ON_ACTION),0);
    lv_obj_set_style_bg_opa(b,255,0);lv_obj_set_style_border_width(b,0,0);
    lv_obj_set_style_radius(b,round_ball?LV_RADIUS_CIRCLE:lv_obj_get_style_height(b,0)/2,0);
    if(th_ringlike() || !strcmp(name,"Braun")){
        neutral_button(b);
        if(th_disco()){
            lv_obj_set_style_bg_opa(b,theme_variant()?220:190,0);lv_obj_set_style_border_color(b,TC(TEXT_PRIMARY),0);lv_obj_set_style_border_opa(b,60,0);
        }else if(th_ringlike()){
            int rgb=cfg_get_int("accent_color",(int)theme_rgb(THEME_CLR_ACCENT_PRIMARY));
            lv_color_t accent=cfg_get_int("accent_mode",1)==1?theme_color_from_rgb((uint32_t)rgb):TC(ACCENT_PRIMARY);
            lv_obj_set_style_border_width(b,2,0);lv_obj_set_style_border_color(b,accent,0);lv_obj_set_style_text_color(b,accent,0);
        }
    }else if(!strcmp(name,"hi-fi")){
        lv_obj_set_style_radius(b,6,0);lv_obj_set_style_border_width(b,1,0);lv_obj_set_style_border_color(b,TC(BORDER_STRONG),0);
    }else if(!strcmp(name,"terminal") || !strcmp(name,"blueprint")){
        neutral_button(b);lv_obj_set_style_radius(b,0,0);lv_obj_set_style_bg_opa(b,0,0);
        lv_obj_set_style_bg_opa(b,255,LV_STATE_PRESSED);lv_obj_set_style_bg_color(b,TC(SURFACE_SELECTED),LV_STATE_PRESSED);
        lv_obj_set_style_border_color(b,!strcmp(name,"blueprint")?TC(ACCENT_PRIMARY):TC(TEXT_SECONDARY),0);
        if(!strcmp(name,"blueprint"))lv_obj_set_style_text_color(b,TC(ACCENT_PRIMARY),0);
    }else if(!strcmp(name,"bauhaus"))lv_obj_set_style_radius(b,0,0);
    else if(!strcmp(name,"zine"))lv_obj_set_style_radius(b,0,0);
    else if(!strcmp(name,"stone")){
        lv_obj_set_style_radius(b,LV_RADIUS_CIRCLE,0);lv_obj_set_style_translate_y(b,2,LV_STATE_PRESSED);
        lv_obj_set_style_shadow_width(b,1,0);lv_obj_set_style_shadow_spread(b,1,0);lv_obj_set_style_shadow_ofs_y(b,3,0);lv_obj_set_style_shadow_color(b,TC(DOT_GRID),0);
    }else if(!strcmp(name,"something")){
        neutral_button(b);lv_obj_set_style_radius(b,LV_RADIUS_CIRCLE,0);lv_obj_set_style_bg_color(b,TC(SURFACE),0);
        lv_obj_set_style_border_color(b,TC(ACCENT_PRIMARY),LV_STATE_PRESSED);
    }
    /* The roulette ball remains round even when the theme's text buttons are square. */
    if(round_ball)lv_obj_set_style_radius(b,LV_RADIUS_CIRCLE,0);
    lv_obj_remove_style_all(l);
    int letter_space=!strcmp(name,"hi-fi")?1:0;lv_obj_set_style_text_letter_space(l,letter_space,0);
    const lv_font_t *font=TF(UI_22);int available=lv_obj_get_style_width(b,0)-8;
    for(int attempts=0;attempts<5;attempts++){
        lv_point_t size;lv_text_get_size(&size,lv_label_get_text(l),font,letter_space,0,LV_COORD_MAX,LV_TEXT_FLAG_NONE);
        if(size.x<=available)break;const lv_font_t *smaller=theme_font_smaller(font);if(!smaller || smaller==font)break;font=smaller;
    }
    lv_obj_set_style_text_font(l,font,0);lv_obj_center(l);
    lv_obj_set_style_text_color(b,TC(TEXT_DISABLED),LV_STATE_DISABLED);
}
