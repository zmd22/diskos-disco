/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdatomic.h>
#include <stdint.h>
#include "musicdb.h"
#define DISC 268
#define POOL 37
#define MIN_TRACKS 4
typedef struct {
    mdb_album_key_t key;
    char path[1024];
    uint32_t *pixels;
    int pixels_mapped;
} album_t;
extern album_t albums[POOL];
extern int album_count;
extern atomic_int prepared, progress, cancelled;
extern char load_error[160];
void *prepare_albums(void *unused);
int play_album(int index, char *error, int cap);
uint32_t random_below(uint32_t n);
void placeholder(uint32_t *p, int seed);
void release_artwork(album_t *album);
